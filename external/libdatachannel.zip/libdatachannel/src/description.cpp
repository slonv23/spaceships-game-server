/**
 * Copyright (c) 2019 Paul-Louis Ageneau
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 */

#include "description.hpp"

#include <algorithm>
#include <cctype>
#include <chrono>
#include <random>
#include <sstream>

using std::size_t;
using std::string;

namespace {

inline bool hasprefix(const string &str, const string &prefix) {
	return str.size() >= prefix.size() &&
	       std::mismatch(prefix.begin(), prefix.end(), str.begin()).first == prefix.end();
}

inline void trim_end(string &str) {
	str.erase(
	    std::find_if(str.rbegin(), str.rend(), [](char c) { return !std::isspace(c); }).base(),
	    str.end());
}

} // namespace

namespace rtc {

Description::Description(const string &sdp, const string &typeString)
    : Description(sdp, stringToType(typeString)) {}

Description::Description(const string &sdp, Type type) : Description(sdp, type, Role::ActPass) {}

Description::Description(const string &sdp, Type type, Role role)
    : mType(Type::Unspec), mRole(role), mMid("0"), mIceUfrag(""), mIcePwd(""), mTrickle(true) {
	hintType(type);

	auto seed = std::chrono::system_clock::now().time_since_epoch().count();
	std::default_random_engine generator(seed);
	std::uniform_int_distribution<uint32_t> uniform;
	mSessionId = std::to_string(uniform(generator));

	std::istringstream ss(sdp);
	string line;
	while (std::getline(ss, line)) {
		trim_end(line);
		if (hasprefix(line, "a=setup:")) {
			const string setup = line.substr(line.find(':') + 1);
			if (setup == "active")
				mRole = Role::Active;
			else if (setup == "passive")
				mRole = Role::Passive;
			else
				mRole = Role::ActPass;
		} else if (hasprefix(line, "a=mid:")) {
			mMid = line.substr(line.find(':') + 1);
		} else if (hasprefix(line, "a=fingerprint:sha-256")) {
			mFingerprint = line.substr(line.find(' ') + 1);
			std::transform(mFingerprint->begin(), mFingerprint->end(), mFingerprint->begin(),
						   [](char c) { return std::toupper(c); });
		} else if (hasprefix(line, "a=ice-ufrag")) {
			mIceUfrag = line.substr(line.find(':') + 1);
		} else if (hasprefix(line, "a=ice-pwd")) {
			mIcePwd = line.substr(line.find(':') + 1);
		} else if (hasprefix(line, "a=sctp-port")) {
			mSctpPort = uint16_t(std::stoul(line.substr(line.find(':') + 1)));
		} else if (hasprefix(line, "a=max-message-size")) {
			mMaxMessageSize = size_t(std::stoul(line.substr(line.find(':') + 1)));
		} else if (hasprefix(line, "a=candidate")) {
			addCandidate(Candidate(line.substr(2), mMid));
		} else if (hasprefix(line, "a=end-of-candidates")) {
			mTrickle = false;
		}
	}
}

Description::Type Description::type() const { return mType; }

string Description::typeString() const { return typeToString(mType); }

Description::Role Description::role() const { return mRole; }

string Description::roleString() const { return roleToString(mRole); }

string Description::mid() const { return mMid; }

std::optional<string> Description::fingerprint() const { return mFingerprint; }

std::optional<uint16_t> Description::sctpPort() const { return mSctpPort; }

std::optional<size_t> Description::maxMessageSize() const { return mMaxMessageSize; }

bool Description::trickleEnabled() const { return mTrickle; }

void Description::hintType(Type type) {
	if (mType == Type::Unspec) {
		mType = type;
		if (mType == Type::Answer && mRole == Role::ActPass)
			mRole = Role::Passive; // ActPass is illegal for an answer, so default to passive
	}
}

void Description::setFingerprint(string fingerprint) {
	mFingerprint.emplace(std::move(fingerprint));
}

void Description::setSctpPort(uint16_t port) { mSctpPort.emplace(port); }

void Description::setMaxMessageSize(size_t size) { mMaxMessageSize.emplace(size); }

void Description::addCandidate(Candidate candidate) {
	mCandidates.emplace_back(std::move(candidate));
}

void Description::endCandidates() { mTrickle = false; }

std::vector<Candidate> Description::extractCandidates() {
	std::vector<Candidate> result;
	std::swap(mCandidates, result);
	mTrickle = true;
	return result;
}

Description::operator string() const { return generateSdp("\r\n"); }

string Description::generateSdp(const string &eol) const {
	if (!mFingerprint)
		throw std::logic_error("Fingerprint must be set to generate an SDP string");

	std::ostringstream sdp;
	sdp << "v=0" << eol;
	sdp << "o=- " << mSessionId << " 0 IN IP4 127.0.0.1" << eol;
	sdp << "s=-" << eol;
	sdp << "t=0 0" << eol;
	sdp << "a=group:BUNDLE 0" << eol;
	sdp << "m=application 9 UDP/DTLS/SCTP webrtc-datachannel" << eol;
	sdp << "c=IN IP4 0.0.0.0" << eol;
	sdp << "a=ice-ufrag:" << mIceUfrag << eol;
	sdp << "a=ice-pwd:" << mIcePwd << eol;
	if (mTrickle)
		sdp << "a=ice-options:trickle" << eol;
	sdp << "a=mid:" << mMid << eol;
	sdp << "a=setup:" << roleToString(mRole) << eol;
	sdp << "a=dtls-id:1" << eol;
	if (mFingerprint)
		sdp << "a=fingerprint:sha-256 " << *mFingerprint << eol;
	if (mSctpPort)
		sdp << "a=sctp-port:" << *mSctpPort << eol;
	if (mMaxMessageSize)
		sdp << "a=max-message-size:" << *mMaxMessageSize << eol;
	for (const auto &candidate : mCandidates) {
		sdp << string(candidate) << eol;
	}

	if (!mTrickle)
		sdp << "a=end-of-candidates" << eol;

	return sdp.str();
}

Description::Type Description::stringToType(const string &typeString) {
	if (typeString == "offer")
		return Type::Offer;
	else if (typeString == "answer")
		return Type::Answer;
	else
		return Type::Unspec;
}

string Description::typeToString(Type type) {
	switch (type) {
	case Type::Offer:
		return "offer";
	case Type::Answer:
		return "answer";
	default:
		return "";
	}
}

string Description::roleToString(Role role) {
	switch (role) {
	case Role::Active:
		return "active";
	case Role::Passive:
		return "passive";
	default:
		return "actpass";
	}
}

} // namespace rtc

std::ostream &operator<<(std::ostream &out, const rtc::Description &description) {
	return out << std::string(description);
}

